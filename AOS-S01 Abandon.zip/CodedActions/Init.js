(function() {
	"use strict";

	function actionInit() {}
	actionInit();

})();